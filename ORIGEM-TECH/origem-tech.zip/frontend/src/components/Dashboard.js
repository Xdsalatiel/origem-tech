import React, { useEffect, useState } from 'react';
import { api } from '../services/api';

export default function Dashboard() {
  const [msg, setMsg] = useState('');

  useEffect(() => {
    const token = localStorage.getItem('token');
    api.get('/dashboard', { headers: { Authorization: token } })
      .then(res => setMsg(res.data.msg))
      .catch(() => setMsg('Erro ao acessar dashboard'));
  }, []);

  return (
    <div>
      <h1>Dashboard</h1>
      <p>{msg}</p>
    </div>
  );
}