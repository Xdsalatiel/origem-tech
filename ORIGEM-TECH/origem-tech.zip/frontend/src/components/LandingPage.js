import React from 'react';
import { Link } from 'react-router-dom';

export default function LandingPage() {
  return (
    <div>
      <header>
        <h1>Origem Tech</h1>
        <a href="https://wa.me/5548998284253" target="_blank" rel="noopener noreferrer">WhatsApp</a>
        <Link to="/login">Área do Cliente</Link>
      </header>

      <section className="hero">
        <h2>Sites e Sistemas Profissionais</h2>
        <p>Transformamos ideias em soluções digitais</p>
        <a href="https://wa.me/5548998284253" target="_blank" rel="noopener noreferrer" className="btn">Fale Conosco</a>
      </section>

      <section>
        <h2>Serviços</h2>
        <ul>
          <li>Criação de Sites</li>
          <li>Sistemas Web</li>
          <li>Automação</li>
        </ul>
      </section>

      <footer>
        <p>© 2026 Origem Tech | WhatsApp: +55 48 99828-4253</p>
      </footer>
    </div>
  );
}