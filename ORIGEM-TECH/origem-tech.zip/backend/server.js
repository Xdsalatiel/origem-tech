require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const Usuario = require('./models/Usuario');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB conectado"))
  .catch(err => console.log(err));

app.post('/register', async (req, res) => {
  const { email, senha } = req.body;
  const hashedPassword = await bcrypt.hash(senha, 10);
  const user = new Usuario({ email, senha: hashedPassword });
  await user.save();
  res.send("Usuário cadastrado com sucesso!");
});

app.post('/login', async (req, res) => {
  const { email, senha } = req.body;
  const user = await Usuario.findOne({ email });
  if (!user) return res.status(401).send("Usuário não encontrado");
  const isMatch = await bcrypt.compare(senha, user.senha);
  if (!isMatch) return res.status(401).send("Senha incorreta");
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1d' });
  res.json({ token });
});

app.get('/dashboard', async (req, res) => {
  const token = req.headers['authorization'];
  if (!token) return res.status(401).send("Acesso negado");
  try {
    const verified = jwt.verify(token, process.env.JWT_SECRET);
    res.json({ msg: "Bem-vindo ao dashboard Origem Tech", userId: verified.id });
  } catch {
    res.status(401).send("Token inválido");
  }
});

app.listen(5000, () => console.log("Backend rodando na porta 5000"));